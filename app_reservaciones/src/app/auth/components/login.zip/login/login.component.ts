import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { Role } from '../../../models/Role';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent {
  loginData = {
    email: '',
    password: '',
  };
  hidePassword = true;

  constructor(private authService: AuthService, private router: Router) {}

  onSubmit() {
    if (!this.loginData.email || !this.loginData.password) {
      this.authService.openConfirmationDialog(
        'Campos Requeridos',
        'Debes completar ambos campos para iniciar sesión.',
        'red'
      );
      return;
    }

    console.log('Iniciando proceso de login');
    console.log('Datos capturados del login:', this.loginData);

    this.authService.login(this.loginData).subscribe({
      next: (response) => {
        console.log('Respuesta de la API de login:', response);

        if (response?.data?.usuario) {
          const usuario = response.data.usuario;

          console.log('Usuario extraído de la respuesta de la API:', usuario);

          if (!usuario.verificado) {
            this.authService.openConfirmationDialog(
              'Cuenta no verificada',
              'Por favor, verifica tu cuenta antes de iniciar sesión.',
              'red'
            );
            return;
          }

          if (usuario.twoFactorEnabled) {
            this.authService.setTempUserData(usuario, response.data.jwt);
            this.router.navigate(['/auth/two-factor']);
            return;
          }

          const isAdmin = usuario.roles.some((role: Role) => role.nombre === 'ADMIN');
          if (isAdmin) {
            this.router.navigate(['/admin']);
          } else {
            this.router.navigate(['/user']);
          }
        } else {
          this.authService.openConfirmationDialog(
            'Credenciales incorrectas',
            'El correo o la contraseña no son correctos.',
            'red'
          );
        }
      },
      error: (error) => {
        // Verifica si el código de estado es 400 para credenciales incorrectas
        if (error.status === 400) {
          this.authService.openConfirmationDialog(
            'Credenciales incorrectas',
            'El correo o la contraseña no son correctos.',
            'red'
          );
        } else {
          this.authService.openConfirmationDialog(
            'Error',
            'Ha ocurrido un error al intentar iniciar sesión.',
            'red'
          );
        }
      },
    });
  }
}
